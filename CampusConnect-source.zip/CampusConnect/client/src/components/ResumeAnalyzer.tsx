import { useRef, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import "./ResumeAnalyzer.css";

type Profile = { studentId?: string; branch?: string; year?: number; skills?: string; interests?: string; bio?: string } | null;
type Analysis = {
  education: string[];
  skills: string[];
  projects: { name: string; summary: string; skills: string[] }[];
  experience: { role: string; organization: string; period: string; highlights: string[] }[];
  targetFit: { matchedSkills: string[]; skillGaps: string[]; suggestions: string[] };
  resumeSuggestions: string[];
  selectedOpportunity: { id: number; title: string; organization: string; type: string } | null;
  recommendations: { id: number; title: string; organization: string; type: string; isDemo: boolean; isVerified: boolean; deadline: Date | string; externalUrl: string; reason: string; matchedSkills: string[]; skillGaps: string[] }[];
};
type Opportunity = { id: number; title: string; organization: string; type: string };
const MAX_PDF_BYTES = 5 * 1024 * 1024;

function List({ items }: { items?: string[] }) {
  if (!items?.length) return <p className="ra-muted">None identified.</p>;
  return <ul>{items.map((item, index) => <li key={`${item}-${index}`}>{item}</li>)}</ul>;
}

export default function ResumeAnalyzer({ profile, onProfileSaved }: { profile: any; onProfileSaved: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [filename, setFilename] = useState("");
  const [fileError, setFileError] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [analysisError, setAnalysisError] = useState("");
  const opportunities = trpc.resume.opportunities.useQuery();
  const analyze = trpc.resume.analyze.useMutation();
  const saveProfile = trpc.profile.save.useMutation({
    onSuccess: () => { toast.success("Extracted skills added to your profile"); onProfileSaved(); },
    onError: error => toast.error(`Could not update your profile: ${error.message}`),
  });

  const chooseFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    setAnalysis(null);
    setAnalysisError("");
    setFileError("");
    setFilename("");
    analyze.reset();
    if (!file) return;
    if (file.size > MAX_PDF_BYTES) { setFileError("Choose a PDF no larger than 5 MiB."); event.currentTarget.value = ""; return; }
    if ((file.type && file.type !== "application/pdf") || !file.name.toLowerCase().endsWith(".pdf")) {
      setFileError("The selected file must be a PDF (.pdf)."); event.currentTarget.value = ""; return;
    }
    setFilename(file.name);
  };

  const runAnalysis = async () => {
    const file = inputRef.current?.files?.[0];
    if (!file) { setFileError("Select a PDF before analyzing."); return; }
    setAnalysis(null);
    setAnalysisError("");
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Could not read this file."));
        reader.onerror = () => reject(new Error("Could not read this file. Please try again."));
        reader.readAsDataURL(file);
      });
      const pdfBase64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
      const result = await analyze.mutateAsync({ pdfBase64, ...(selectedId ? { opportunityId: Number(selectedId) } : {}) });
      setAnalysis(result as Analysis);
    } catch (error) {
      setAnalysisError(`Analysis could not be completed${error instanceof Error && error.message ? `: ${error.message}` : "."} Please try again.`);
    } finally {
      if (inputRef.current) inputRef.current.value = "";
      setFilename("");
      analyze.reset();
    }
  };

  const addSkills = () => {
    if (!profile || !analysis?.skills.length) return;
    const existing = String(profile.skills ?? "").split(/[,;\n]/).map((skill: string) => skill.trim()).filter(Boolean);
    const seen = new Set(existing.map((skill: string) => skill.toLocaleLowerCase()));
    const merged = [...existing];
    analysis.skills.forEach(skill => {
      const clean = skill.trim();
      if (clean && !seen.has(clean.toLocaleLowerCase())) { seen.add(clean.toLocaleLowerCase()); merged.push(clean); }
    });
    saveProfile.mutate({
      studentId: String(profile.studentId ?? ""), branch: String(profile.branch ?? ""), year: Number(profile.year),
      skills: merged.join(", "), interests: String(profile.interests ?? ""), bio: String(profile.bio ?? ""),
    });
  };

  const listingData = opportunities.data as Opportunity[] | undefined;
  return <section className="resume-analyzer" aria-labelledby="resume-analyzer-title">
    <header className="ra-heading"><div><span className="ra-eyebrow">CAREER TOOL</span><h2 id="resume-analyzer-title">AI Resume Analyzer</h2><p>Review resume content and discover relevant opportunities.</p></div></header>
    <div className="ra-privacy" role="note"><strong>Privacy &amp; use</strong><p>Your selected PDF is sent to CampusConnect for in-memory text extraction. Only after you click Analyze, extracted text, your profile branch, year, current skills and interests (if present), and the selected role plus up to 12 approved current internship/job listings may be sent to Manus AI. CampusConnect does not save your PDF, extracted text, or analysis. No public URL, object storage, localStorage, or database analysis is used.</p></div>
    <div className="ra-controls">
      <label className="ra-label" htmlFor="resume-pdf">Resume PDF <span>(max 5 MiB)</span></label>
      <input ref={inputRef} id="resume-pdf" type="file" accept="application/pdf,.pdf" onChange={chooseFile} aria-describedby="ra-file-help ra-file-error" />
      <span id="ra-file-help" className="ra-muted">Choose a PDF from this device. The file is not retained after the request.</span>
      {filename && <span className="ra-filename">Selected: {filename}</span>}
      {fileError && <p className="ra-error" id="ra-file-error" role="alert">{fileError}</p>}
      <label className="ra-label" htmlFor="resume-opportunity">Compare with an Internship or Job <span>(optional)</span></label>
      <select id="resume-opportunity" value={selectedId} onChange={event => { setSelectedId(event.target.value); setAnalysis(null); setAnalysisError(""); }}>
        <option value="">No target role</option>
        {listingData?.map(item => <option key={item.id} value={item.id}>{item.title} — {item.organization}</option>)}
      </select>
      {opportunities.isLoading && <p className="ra-muted" role="status">Loading approved roles… You can analyze without selecting one.</p>}
      {opportunities.isError && <p className="ra-error" role="status">Roles could not be loaded. You can still analyze without a target role.</p>}
      {!opportunities.isLoading && !opportunities.isError && listingData?.length === 0 && <p className="ra-muted">No approved, current Internship or Job listings are available. You can still analyze without a target role.</p>}
      <button className="ra-primary" type="button" onClick={runAnalysis} disabled={!filename || analyze.isPending}>
        {analyze.isPending ? "Analyzing…" : "Analyze resume"}
      </button>
      {analyze.isPending && <p className="ra-muted" role="status">Sending your resume for analysis. This may take a moment.</p>}
      {analysisError && <p className="ra-error" role="alert">{analysisError}</p>}
    </div>
    {analysis && <div className="ra-results" aria-live="polite">
      <h3>Analysis results</h3>
      <section className="ra-result-section"><h4>Education</h4><List items={analysis.education}/></section>
      <section className="ra-result-section"><h4>Skills</h4><List items={analysis.skills}/></section>
      <section className="ra-result-section"><h4>Projects</h4>{analysis.projects.length ? analysis.projects.map((project, i) => <article className="ra-item" key={`${project.name}-${i}`}><strong>{project.name}</strong><p>{project.summary}</p><List items={project.skills}/></article>) : <p className="ra-muted">None identified.</p>}</section>
      <section className="ra-result-section"><h4>Experience</h4>{analysis.experience.length ? analysis.experience.map((item, i) => <article className="ra-item" key={`${item.role}-${i}`}><strong>{item.role} · {item.organization}</strong><span>{item.period}</span><List items={item.highlights}/></article>) : <p className="ra-muted">None identified.</p>}</section>
      {analysis.selectedOpportunity && <section className="ra-result-section"><h4>Target role: {analysis.selectedOpportunity.title} · {analysis.selectedOpportunity.organization}</h4><div className="ra-columns"><div><strong>Matched skills</strong><List items={analysis.targetFit.matchedSkills}/></div><div><strong>Skill gaps</strong><List items={analysis.targetFit.skillGaps}/></div></div><strong>Suggestions</strong><List items={analysis.targetFit.suggestions}/></section>}
      <section className="ra-result-section"><h4>Resume suggestions</h4><List items={analysis.resumeSuggestions}/></section>
      <section className="ra-result-section"><h4>Opportunity recommendations</h4>{analysis.recommendations.length ? analysis.recommendations.map(item => <article className="ra-item ra-recommendation" key={item.id}><div className="ra-rec-title"><strong>{item.title}</strong>{item.isDemo && <span className="ra-demo">DEMO DATA</span>}{item.isVerified && <span className="ra-verified">Verified</span>}</div><span>{item.organization} · {item.type}</span><p>{item.reason}</p><div className="ra-columns"><div><strong>Matched skills</strong><List items={item.matchedSkills}/></div><div><strong>Skill gaps</strong><List items={item.skillGaps}/></div></div>{item.externalUrl && <a href={item.externalUrl} target="_blank" rel="noreferrer">Open listing <span className="ra-sr-only">(opens in a new tab)</span></a>}</article>) : <p className="ra-muted">No recommendations identified.</p>}</section>
      {profile && analysis.skills.length > 0 ? <div className="ra-save-skills"><p>Review the extracted skills above. Nothing is saved until you choose this action.</p><button type="button" className="ra-secondary" onClick={addSkills} disabled={saveProfile.isPending}>{saveProfile.isPending ? "Saving skills…" : "Add extracted skills to my profile"}</button></div> : !profile && analysis.skills.length > 0 ? <p className="ra-profile-note">Create a student profile to save extracted skills to your profile.</p> : null}
    </div>}
  </section>;
}
