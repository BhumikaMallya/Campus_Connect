import { getDocument } from "pdfjs-dist/legacy/build/pdf.mjs";

export const MAX_RESUME_PDF_BYTES = 5 * 1024 * 1024;
export const MAX_RESUME_PDF_PAGES = 8;
export const MAX_RESUME_TEXT_CHARS = 20_000;

export class ResumePdfError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ResumePdfError";
  }
}

/** Parse a text-based PDF in process memory; never write the supplied bytes to disk. */
export async function extractResumeTextFromPdf(
  pdfBytes: Uint8Array
): Promise<{ text: string; pageCount: number }> {
  if (pdfBytes.byteLength === 0) {
    throw new ResumePdfError("Choose a non-empty PDF resume.");
  }
  if (pdfBytes.byteLength > MAX_RESUME_PDF_BYTES) {
    throw new ResumePdfError("PDF resumes must be 5 MiB or smaller.");
  }
  if (Buffer.from(pdfBytes.subarray(0, 5)).toString("ascii") !== "%PDF-") {
    throw new ResumePdfError("The uploaded file is not a valid PDF.");
  }

  const loadingTask = getDocument({
    data: new Uint8Array(pdfBytes),
    disableFontFace: true,
    isEvalSupported: false,
    stopAtErrors: true,
    useSystemFonts: true,
  });

  try {
    const document = await loadingTask.promise;
    if (document.numPages > MAX_RESUME_PDF_PAGES) {
      throw new ResumePdfError(
        `PDF resumes must have ${MAX_RESUME_PDF_PAGES} pages or fewer.`
      );
    }

    const parts: string[] = [];
    let textLength = 0;
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent({ includeMarkedContent: false });
      for (const item of content.items) {
        if (!("str" in item) || !item.str) continue;
        const text = `${item.str}${item.hasEOL ? "\n" : " "}`;
        textLength += text.length;
        if (textLength > MAX_RESUME_TEXT_CHARS) {
          throw new ResumePdfError(
            `This PDF contains too much text. Keep the extracted resume under ${MAX_RESUME_TEXT_CHARS.toLocaleString()} characters.`
          );
        }
        parts.push(text);
      }
      page.cleanup();
    }

    const text = parts
      .join("")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    if (!text) {
      throw new ResumePdfError(
        "No selectable text was found. Scanned or image-only PDFs need OCR, which is not supported yet."
      );
    }

    return { text, pageCount: document.numPages };
  } catch (error) {
    if (error instanceof ResumePdfError) throw error;
    throw new ResumePdfError(
      "The PDF could not be read. Upload an unencrypted, text-based PDF."
    );
  } finally {
    await loadingTask.destroy().catch(() => undefined);
  }
}
