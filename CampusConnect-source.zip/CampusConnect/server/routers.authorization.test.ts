import { describe, expect, it } from "vitest";
import type { User } from "../drizzle/schema";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function makeUser(overrides: Partial<User> = {}): User {
  const now = new Date();
  return {
    id: 10,
    openId: "authorization-test-user",
    name: "Authorization Test",
    email: "authorization-test@example.invalid",
    loginMethod: "manus",
    role: "user",
    isActive: true,
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
    ...overrides,
  };
}

function makeContext(user: AuthenticatedUser | null): TrpcContext {
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as unknown as TrpcContext["res"],
  };
}

const validPdfBase64 = Buffer.from("%PDF-1.4\n%synthetic test input").toString("base64");

describe("router authorization", () => {
  it("requires an authenticated active account for student application data", async () => {
    const caller = appRouter.createCaller(makeContext(null));
    await expect(caller.applications.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(caller.profile.get()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects student accounts from administrator queries and mutations", async () => {
    const caller = appRouter.createCaller(makeContext(makeUser()));
    await expect(caller.admin.stats()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.students()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.deleteOpportunity({ id: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.deleteAnnouncement({ id: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.admin.updateAccount({ id: 11, role: "admin", isActive: true })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects administrator privileges when an admin account is inactive", async () => {
    const caller = appRouter.createCaller(makeContext(makeUser({ role: "admin", isActive: false })));
    await expect(caller.admin.stats()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("restricts resume analysis and current listing options to active student accounts", async () => {
    const anonymous = appRouter.createCaller(makeContext(null));
    await expect(anonymous.resume.opportunities()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(anonymous.resume.analyze({ pdfBase64: validPdfBase64 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });

    const admin = appRouter.createCaller(makeContext(makeUser({ role: "admin" })));
    await expect(admin.resume.opportunities()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(admin.resume.analyze({ pdfBase64: validPdfBase64 })).rejects.toMatchObject({ code: "FORBIDDEN" });

    const inactiveStudent = appRouter.createCaller(makeContext(makeUser({ isActive: false })));
    await expect(inactiveStudent.resume.opportunities()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(inactiveStudent.resume.analyze({ pdfBase64: validPdfBase64 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
