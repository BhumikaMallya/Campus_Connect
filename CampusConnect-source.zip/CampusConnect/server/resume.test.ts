import { describe, expect, it } from "vitest";
import type { Opportunity } from "../drizzle/schema";
import {
  buildValidatedRecommendations,
  filterToRequiredSkills,
} from "./resume";
import {
  extractResumeTextFromPdf,
  MAX_RESUME_PDF_BYTES,
  ResumePdfError,
} from "./_core/resumePdf";

function escapePdfString(value: string) {
  return value.replaceAll("\\", "\\\\").replaceAll("(", "\\(").replaceAll(")", "\\)");
}

function makeTextPdf(pages: string[][]): Buffer {
  const objects: string[] = [];
  const pageIds = pages.map((_, index) => 4 + index * 2);
  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[2] = `<< /Type /Pages /Kids [${pageIds.map(id => `${id} 0 R`).join(" ")}] /Count ${pages.length} >>`;
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";

  pages.forEach((lines, index) => {
    const pageId = pageIds[index];
    const streamId = pageId + 1;
    const text = lines.map((line, lineIndex) => `${lineIndex ? "0 -18 Td\n" : ""}(${escapePdfString(line)}) Tj`).join("\n");
    const stream = `BT\n/F1 11 Tf\n72 720 Td\n${text}\nET\n`;
    objects[pageId] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents ${streamId} 0 R >>`;
    objects[streamId] = `<< /Length ${Buffer.byteLength(stream, "ascii")} >>\nstream\n${stream}endstream`;
  });

  let body = Buffer.from("%PDF-1.7\n", "ascii");
  const offsets = [0];
  for (let id = 1; id < objects.length; id++) {
    offsets[id] = body.byteLength;
    body = Buffer.concat([body, Buffer.from(`${id} 0 obj\n${objects[id]}\nendobj\n`, "ascii")]);
  }
  const xrefOffset = body.byteLength;
  const xref = ["xref", `0 ${objects.length}`, "0000000000 65535 f "];
  for (let id = 1; id < objects.length; id++) {
    xref.push(`${String(offsets[id]).padStart(10, "0")} 00000 n `);
  }
  const trailer = `${xref.join("\n")}\ntrailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`;
  return Buffer.concat([body, Buffer.from(trailer, "ascii")]);
}

const now = new Date("2026-11-21T00:00:00Z");
const candidate: Opportunity = {
  id: 17,
  title: "Frontend Intern",
  organization: "Example Studio",
  type: "Internship",
  location: "Remote",
  workMode: "Remote",
  description: "Build and test product interfaces.",
  eligibility: "Current students.",
  branches: "All branches",
  skills: "React, TypeScript",
  deadline: new Date("2026-12-21T00:00:00Z"),
  externalUrl: "https://example.invalid/listing",
  compensation: null,
  approval: "approved",
  isVerified: false,
  isDemo: true,
  createdBy: null,
  createdAt: now,
  updatedAt: now,
};

describe("resume PDF extraction", () => {
  it("extracts selectable text from a synthetic PDF in memory", async () => {
    const pdf = makeTextPdf([["Synthetic Student Resume", "Education: BSc Computer Science, 2024–2027", "Skills: React, TypeScript"]]);
    const result = await extractResumeTextFromPdf(pdf);
    expect(result.pageCount).toBe(1);
    expect(result.text).toContain("Synthetic Student Resume");
    expect(result.text).toContain("React, TypeScript");
  });

  it("rejects non-PDF signatures and oversize input before parsing", async () => {
    await expect(extractResumeTextFromPdf(Buffer.from("not a PDF"))).rejects.toBeInstanceOf(ResumePdfError);
    await expect(extractResumeTextFromPdf(Buffer.alloc(MAX_RESUME_PDF_BYTES + 1))).rejects.toThrow("5 MiB");
  });

  it("rejects scanned/image-only PDFs with an explicit OCR limitation", async () => {
    const scanned = makeTextPdf([[]]);
    await expect(extractResumeTextFromPdf(scanned)).rejects.toThrow("image-only PDFs need OCR");
  });

  it("rejects PDFs over the page bound", async () => {
    const tooManyPages = makeTextPdf(Array.from({ length: 9 }, (_, index) => [`Page ${index + 1}`]));
    await expect(extractResumeTextFromPdf(tooManyPages)).rejects.toThrow("8 pages or fewer");
  });
});

describe("resume opportunity grounding", () => {
  it("keeps only model skills that exactly match the listing's required skills", () => {
    expect(filterToRequiredSkills(["react", "Scala", "TypeScript", "React"], ["React", "TypeScript"]))
      .toEqual(["React", "TypeScript"]);
  });

  it("drops invented opportunity IDs and de-duplicates model recommendations", () => {
    const result = buildValidatedRecommendations([
      { opportunityId: 17, reason: "Your React project supports this role.", matchedSkills: ["react", "Scala"], skillGaps: ["TypeScript", "Rust"] },
      { opportunityId: 999, reason: "This ID is not present in the current listing set.", matchedSkills: [], skillGaps: [] },
      { opportunityId: 17, reason: "Duplicate listing.", matchedSkills: [], skillGaps: [] },
    ], [candidate]);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({ id: 17, isDemo: true, matchedSkills: ["React"], skillGaps: ["TypeScript"] });
    expect(result[0].externalUrl).toBe("https://example.invalid/listing");
  });
});
