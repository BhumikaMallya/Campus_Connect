import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { and, count, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { announcements, applications, opportunities, savedOpportunities, studentProfiles, users } from "../drizzle/schema";
import { getDb, seedDemoData } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { resumeRouter } from "./resume";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";

const opportunityTypes = ["Internship", "Job", "Hackathon", "Technical event", "Workshop", "Competition"] as const;
const applicationStatuses = ["Applied", "Under Review", "Shortlisted", "Interview", "Selected", "Rejected"] as const;
const announcementTypes = ["notice", "placement", "department", "event", "deadline"] as const;
const profileInput = z.object({ studentId: z.string().max(64).optional().default(""), branch: z.string().trim().min(2).max(120), year: z.number().int().min(1).max(8), skills: z.string().max(1600).default(""), interests: z.string().max(1000).default(""), bio: z.string().max(1000).default("") });
const listingInput = z.object({ id: z.number().int().positive().optional(), title: z.string().trim().min(4).max(220), organization: z.string().trim().min(2).max(180), type: z.enum(opportunityTypes), location: z.string().trim().min(2).max(180), workMode: z.enum(["Remote", "Hybrid", "On campus", "In person"]), description: z.string().trim().min(20).max(6000), eligibility: z.string().trim().min(4).max(2000), branches: z.string().trim().min(2).max(1000), skills: z.string().max(1000).default(""), deadline: z.string().min(1), externalUrl: z.string().url().max(1000), compensation: z.string().max(140).default(""), approval: z.enum(["pending", "approved", "rejected"]).default("approved") });
const announcementInput = z.object({ id: z.number().int().positive().optional(), title: z.string().trim().min(4).max(220), body: z.string().trim().min(10).max(5000), type: z.enum(announcementTypes), department: z.string().max(150).default(""), deadline: z.string().optional().default(""), isPublished: z.boolean().default(true) });

function tokenize(value: string | null | undefined) { return (value ?? "").split(/[,;\n]/).map(item => item.trim().toLowerCase()).filter(Boolean); }
function isDuplicateKeyError(error: unknown) {
  let current = error;
  const seen = new Set<object>();
  while (current && typeof current === "object" && !seen.has(current)) {
    const mysqlError = current as { code?: unknown; errno?: unknown; cause?: unknown };
    if (mysqlError.code === "ER_DUP_ENTRY" || mysqlError.errno === 1062) return true;
    seen.add(current);
    current = mysqlError.cause;
  }
  return false;
}
function eligibleFor(profile: typeof studentProfiles.$inferSelect | undefined, item: typeof opportunities.$inferSelect) {
  if (!profile) return { eligible: false, reasons: ["Add your branch and year to see eligibility matches"] };
  const branchList = tokenize(item.branches);
  const branchMatch = !branchList.length || branchList.some(branch => branch === "all branches" || branch.includes(profile.branch.toLowerCase()) || profile.branch.toLowerCase().includes(branch));
  const studentSkills = tokenize(profile.skills);
  const listingSkills = tokenize(item.skills);
  const skillMatches = studentSkills.filter(skill => listingSkills.some(target => target.includes(skill) || skill.includes(target)));
  const reasons = [branchMatch ? `Branch match: ${profile.branch}` : `Branch requirement: ${item.branches}`, ...skillMatches.slice(0, 2).map(skill => `Skill match: ${skill}`)];
  if (!skillMatches.length && listingSkills.length) reasons.push(`Build toward: ${listingSkills.slice(0, 2).join(", ")}`);
  return { eligible: branchMatch, reasons };
}
function explainRecommendation(profile: typeof studentProfiles.$inferSelect, item: typeof opportunities.$inferSelect) {
  const match = eligibleFor(profile, item);
  const skillMatches = tokenize(profile.skills).filter(skill => tokenize(item.skills).some(target => target.includes(skill) || skill.includes(target)));
  const interestMatches = tokenize(profile.interests).filter(term => `${item.title} ${item.organization} ${item.description} ${item.type}`.toLowerCase().includes(term));
  const reasons = [...match.reasons, ...interestMatches.slice(0, 2).map(term => `Interest match: ${term}`)];
  const score = Math.min(98, 48 + (match.eligible ? 24 : 0) + skillMatches.length * 10 + interestMatches.length * 8);
  return { ...item, eligible: match.eligible, reasons, score };
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, ctx.user.id)).limit(1);
      return profile ?? null;
    }),
    save: protectedProcedure.input(profileInput).mutation(async ({ ctx, input }) => {
      if (ctx.user.role === "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin accounts do not need a student profile." });
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const values = { userId: ctx.user.id, studentId: input.studentId || null, branch: input.branch, year: input.year, skills: input.skills, interests: input.interests, bio: input.bio || null };
      await db.insert(studentProfiles).values(values).onDuplicateKeyUpdate({ set: { ...values, userId: ctx.user.id } });
      const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, ctx.user.id)).limit(1);
      return profile;
    }),
  }),
  resume: resumeRouter,
  opportunities: router({
    list: publicProcedure.input(z.object({ type: z.enum(opportunityTypes).optional(), search: z.string().max(200).optional(), limit: z.number().int().min(1).max(100).default(60) }).optional()).query(async ({ input }) => {
      await seedDemoData();
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const rows = await db.select().from(opportunities).where(eq(opportunities.approval, "approved")).orderBy(desc(opportunities.createdAt)).limit(input?.limit ?? 60);
      const q = input?.search?.trim().toLowerCase();
      return rows.filter(item => (!input?.type || item.type === input.type) && (!q || [item.title, item.organization, item.type, item.location, item.description, item.skills].some(value => value?.toLowerCase().includes(q))));
    }),
    savedIds: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const rows = await db.select({ opportunityId: savedOpportunities.opportunityId }).from(savedOpportunities).where(eq(savedOpportunities.userId, ctx.user.id));
      return rows.map(row => row.opportunityId);
    }),
    toggleSaved: protectedProcedure.input(z.object({ opportunityId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [existing] = await db.select().from(savedOpportunities).where(and(eq(savedOpportunities.userId, ctx.user.id), eq(savedOpportunities.opportunityId, input.opportunityId))).limit(1);
      if (existing) { await db.delete(savedOpportunities).where(eq(savedOpportunities.id, existing.id)); return { saved: false }; }
      await db.insert(savedOpportunities).values({ userId: ctx.user.id, opportunityId: input.opportunityId }); return { saved: true };
    }),
    recommended: protectedProcedure.query(async ({ ctx }) => {
      await seedDemoData(); const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, ctx.user.id)).limit(1);
      if (!profile) return [];
      const rows = await db.select().from(opportunities).where(eq(opportunities.approval, "approved")).orderBy(desc(opportunities.createdAt)).limit(80);
      return rows.map(item => explainRecommendation(profile, item)).filter(item => item.eligible).sort((a, b) => b.score - a.score).slice(0, 8);
    }),
  }),
  applications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      return db.select({ id: applications.id, status: applications.status, notes: applications.notes, appliedAt: applications.appliedAt, updatedAt: applications.updatedAt, opportunity: opportunities }).from(applications).innerJoin(opportunities, eq(applications.opportunityId, opportunities.id)).where(eq(applications.userId, ctx.user.id)).orderBy(desc(applications.updatedAt));
    }),
    submit: protectedProcedure.input(z.object({ opportunityId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [item] = await db.select().from(opportunities).where(and(eq(opportunities.id, input.opportunityId), eq(opportunities.approval, "approved"))).limit(1);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Opportunity not found or not open." });
      const [existing] = await db.select().from(applications).where(and(eq(applications.userId, ctx.user.id), eq(applications.opportunityId, input.opportunityId))).limit(1);
      if (existing) return { id: existing.id, alreadyTracked: true, url: item.externalUrl };
      try {
        const [result] = await db.insert(applications).values({ userId: ctx.user.id, opportunityId: input.opportunityId, status: "Applied" });
        return { id: Number(result.insertId), alreadyTracked: false, url: item.externalUrl };
      } catch (error) {
        if (!isDuplicateKeyError(error)) throw error;
        const [raced] = await db.select().from(applications).where(and(eq(applications.userId, ctx.user.id), eq(applications.opportunityId, input.opportunityId))).limit(1);
        if (!raced) throw error;
        return { id: raced.id, alreadyTracked: true, url: item.externalUrl };
      }
    }),
    updateStatus: protectedProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(applicationStatuses) })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.update(applications).set({ status: input.status }).where(and(eq(applications.id, input.id), eq(applications.userId, ctx.user.id)));
      if (!result[0].affectedRows) {
        const [stillExists] = await db.select({ id: applications.id }).from(applications).where(and(eq(applications.id, input.id), eq(applications.userId, ctx.user.id))).limit(1);
        if (!stillExists) throw new TRPCError({ code: "NOT_FOUND", message: "Application not found." });
      }
      return { success: true };
    }),
  }),
  announcements: router({
    list: publicProcedure.query(async () => {
      await seedDemoData(); const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      return db.select().from(announcements).where(eq(announcements.isPublished, true)).orderBy(desc(announcements.createdAt)).limit(30);
    }),
  }),
  dashboard: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      await seedDemoData(); const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [profile] = await db.select().from(studentProfiles).where(eq(studentProfiles.userId, ctx.user.id)).limit(1);
      const [opportunityTotal] = await db.select({ value: count() }).from(opportunities).where(eq(opportunities.approval, "approved"));
      const [applicationTotal] = await db.select({ value: count() }).from(applications).where(eq(applications.userId, ctx.user.id));
      const [savedTotal] = await db.select({ value: count() }).from(savedOpportunities).where(eq(savedOpportunities.userId, ctx.user.id));
      const deadlineRows = await db.select().from(opportunities).where(eq(opportunities.approval, "approved")).orderBy(opportunities.deadline).limit(30);
      const upcoming = deadlineRows.filter(item => item.deadline.getTime() > Date.now()).slice(0, 4);
      const appRows = await db.select({ status: applications.status }).from(applications).where(eq(applications.userId, ctx.user.id));
      const profileScore = profile ? [Boolean(profile.studentId), Boolean(profile.branch), profile.year > 0, tokenize(profile.skills).length > 0, tokenize(profile.interests).length > 0, Boolean(profile.bio)].filter(Boolean).length : 0;
      const applicationScore = Math.min(2, Number(applicationTotal.value));
      const readiness = Math.min(100, Math.round((profileScore / 6) * 80 + applicationScore * 10));
      const recent = await db.select().from(announcements).where(eq(announcements.isPublished, true)).orderBy(desc(announcements.createdAt)).limit(3);
      const recs = profile ? (await db.select().from(opportunities).where(eq(opportunities.approval, "approved")).orderBy(desc(opportunities.createdAt)).limit(40)).map(item => explainRecommendation(profile, item)).filter(item => item.eligible).sort((a, b) => b.score - a.score).slice(0, 4) : [];
      const counts = applicationStatuses.map(status => ({ status, count: appRows.filter(row => row.status === status).length }));
      return { profile: profile ?? null, opportunityTotal: Number(opportunityTotal.value), applicationTotal: Number(applicationTotal.value), savedTotal: Number(savedTotal.value), upcoming, recentAnnouncements: recent, recommendations: recs, readiness, applicationCounts: counts };
    }),
  }),
  admin: router({
    opportunities: adminProcedure.query(async () => {
      await seedDemoData(); const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      return db.select().from(opportunities).orderBy(desc(opportunities.createdAt)).limit(200);
    }),
    saveOpportunity: adminProcedure.input(listingInput).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const values = { title: input.title, organization: input.organization, type: input.type, location: input.location, workMode: input.workMode, description: input.description, eligibility: input.eligibility, branches: input.branches, skills: input.skills, deadline: new Date(input.deadline), externalUrl: input.externalUrl, compensation: input.compensation || null, approval: input.approval };
      if (Number.isNaN(values.deadline.getTime())) throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a valid deadline." });
      if (input.id) {
        const result = await db.update(opportunities).set(values).where(eq(opportunities.id, input.id));
        if (!result[0].affectedRows) {
          const [stillExists] = await db.select({ id: opportunities.id }).from(opportunities).where(eq(opportunities.id, input.id)).limit(1);
          if (!stillExists) throw new TRPCError({ code: "NOT_FOUND", message: "Opportunity not found." });
        }
      }
      else await db.insert(opportunities).values({ ...values, createdBy: ctx.user.id, isVerified: false, isDemo: false });
      return { success: true };
    }),
    deleteOpportunity: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.delete(opportunities).where(eq(opportunities.id, input.id));
      if (!result[0].affectedRows) throw new TRPCError({ code: "NOT_FOUND", message: "Opportunity not found." });
      return { success: true };
    }),
    reviewOpportunity: adminProcedure.input(z.object({ id: z.number().int().positive(), approval: z.enum(["approved", "rejected"]) })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.update(opportunities).set({ approval: input.approval }).where(eq(opportunities.id, input.id));
      if (!result[0].affectedRows) {
        const [stillExists] = await db.select({ id: opportunities.id }).from(opportunities).where(eq(opportunities.id, input.id)).limit(1);
        if (!stillExists) throw new TRPCError({ code: "NOT_FOUND", message: "Opportunity not found." });
      }
      return { success: true };
    }),
    verifyOpportunity: adminProcedure.input(z.object({ id: z.number().int().positive(), verified: z.boolean() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [item] = await db.select().from(opportunities).where(eq(opportunities.id, input.id)).limit(1);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Opportunity not found." });
      if (item.isDemo && input.verified) throw new TRPCError({ code: "BAD_REQUEST", message: "Demo listings cannot be verified. Create a sourced, non-demo listing after review." });
      await db.update(opportunities).set({ isVerified: input.verified }).where(eq(opportunities.id, input.id)); return { success: true };
    }),
    announcements: adminProcedure.query(async () => {
      await seedDemoData(); const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      return db.select().from(announcements).orderBy(desc(announcements.createdAt)).limit(100);
    }),
    saveAnnouncement: adminProcedure.input(announcementInput).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const values = { title: input.title, body: input.body, type: input.type, department: input.department || null, deadline: input.deadline ? new Date(input.deadline) : null, isPublished: input.isPublished };
      if (values.deadline && Number.isNaN(values.deadline.getTime())) throw new TRPCError({ code: "BAD_REQUEST", message: "Enter a valid deadline." });
      if (input.id) {
        const result = await db.update(announcements).set(values).where(eq(announcements.id, input.id));
        if (!result[0].affectedRows) {
          const [stillExists] = await db.select({ id: announcements.id }).from(announcements).where(eq(announcements.id, input.id)).limit(1);
          if (!stillExists) throw new TRPCError({ code: "NOT_FOUND", message: "Announcement not found." });
        }
      }
      else await db.insert(announcements).values({ ...values, createdBy: ctx.user.id, isDemo: false });
      return { success: true };
    }),
    deleteAnnouncement: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const result = await db.delete(announcements).where(eq(announcements.id, input.id));
      if (!result[0].affectedRows) throw new TRPCError({ code: "NOT_FOUND", message: "Announcement not found." });
      return { success: true };
    }),
    students: adminProcedure.query(async () => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      return db.select({ id: users.id, name: users.name, email: users.email, role: users.role, isActive: users.isActive, branch: studentProfiles.branch, year: studentProfiles.year, studentId: studentProfiles.studentId, createdAt: users.createdAt }).from(users).leftJoin(studentProfiles, eq(users.id, studentProfiles.userId)).orderBy(desc(users.createdAt)).limit(250);
    }),
    updateAccount: adminProcedure.input(z.object({ id: z.number().int().positive(), role: z.enum(["user", "admin"]), isActive: z.boolean() })).mutation(async ({ ctx, input }) => {
      const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      if (input.id === ctx.user.id && (!input.isActive || input.role !== "admin")) throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot deactivate or demote your own account." });
      const [target] = await db.select().from(users).where(eq(users.id, input.id)).limit(1);
      if (!target) throw new TRPCError({ code: "NOT_FOUND" });
      if (target.role === "admin" && target.isActive && (!input.isActive || input.role !== "admin")) {
        const [activeAdmins] = await db.select({ value: count() }).from(users).where(and(eq(users.role, "admin"), eq(users.isActive, true)));
        if (Number(activeAdmins.value) <= 1) throw new TRPCError({ code: "BAD_REQUEST", message: "Keep at least one active administrator." });
      }
      await db.update(users).set({ role: input.role, isActive: input.isActive }).where(eq(users.id, input.id)); return { success: true };
    }),
    stats: adminProcedure.query(async () => {
      await seedDemoData(); const db = await getDb(); if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const [totalStudents] = await db.select({ value: count() }).from(users).where(eq(users.role, "user"));
      const [totalOpportunities] = await db.select({ value: count() }).from(opportunities);
      const [totalAnnouncements] = await db.select({ value: count() }).from(announcements);
      const [pendingReview] = await db.select({ value: count() }).from(opportunities).where(eq(opportunities.approval, "pending"));
      const rows = await db.select({ status: applications.status }).from(applications);
      return { students: Number(totalStudents.value), opportunities: Number(totalOpportunities.value), pending: Number(pendingReview.value), applications: rows.length, announcements: Number(totalAnnouncements.value), applicationCounts: applicationStatuses.map(status => ({ status, count: rows.filter(row => row.status === status).length })) };
    }),
  }),
});

export type AppRouter = typeof appRouter;
