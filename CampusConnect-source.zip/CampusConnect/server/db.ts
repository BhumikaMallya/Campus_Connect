import { eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, announcements, opportunities, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
  if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  if (user.isActive !== undefined) { values.isActive = user.isActive; updateSet.isActive = user.isActive; }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

/** Seed only truly empty tables. Every inserted record is labeled demo and unverified. */
let demoSeedInFlight: Promise<void> | null = null;
export async function seedDemoData() {
  if (demoSeedInFlight) return demoSeedInFlight;
  demoSeedInFlight = seedDemoDataOnce();
  try { await demoSeedInFlight; } finally { demoSeedInFlight = null; }
}
async function seedDemoDataOnce() {
  const db = await getDb();
  if (!db) return;
  const [row] = await db.select({ count: sql<number>`count(*)` }).from(opportunities);
  const seedOpportunities = Number(row?.count ?? 0) === 0;
  const [announcementCount] = await db.select({ count: sql<number>`count(*)` }).from(announcements);
  const seedAnnouncements = Number(announcementCount?.count ?? 0) === 0;
  const days = (n: number) => new Date(Date.now() + n * 86400000);
  const items = [
    { title: "Product Engineering Intern", organization: "Northstar Labs", type: "Internship" as const, location: "India · Remote", workMode: "Remote" as const, description: "Contribute to a small product engineering team building tools for modern learning. Pair with mentors, ship scoped features and present your work at the end of the program.", eligibility: "Undergraduate students in years 2–4; comfortable with one programming language.", branches: "Computer Science, Information Technology, Electronics", skills: "React, TypeScript, APIs", deadline: days(9), externalUrl: "https://example.com/opportunities/northstar-intern", compensation: "₹25,000 / month" },
    { title: "Campus Climate Data Challenge", organization: "Open Earth Collective", type: "Hackathon" as const, location: "Online", workMode: "Remote" as const, description: "Build a useful prototype from open climate datasets. Teams receive a starter kit, mentor office hours and a demo day with community reviewers.", eligibility: "Open to all branches; teams of 2–4 students.", branches: "All branches", skills: "Python, Data analysis, Design", deadline: days(6), externalUrl: "https://example.com/events/climate-data-challenge", compensation: "₹1.2 lakh prize pool" },
    { title: "Associate Software Engineer", organization: "Brightpath Systems", type: "Job" as const, location: "Bengaluru, India", workMode: "Hybrid" as const, description: "Entry-level engineering role on the platform team. Work across APIs, testing and reliability with a structured graduate onboarding program.", eligibility: "2026–27 graduates; CS, IT or related discipline.", branches: "Computer Science, Information Technology", skills: "Java, SQL, Problem solving", deadline: days(16), externalUrl: "https://example.com/jobs/brightpath-graduate", compensation: "₹8–12 LPA (demo estimate)" },
    { title: "Frontend Systems Workshop", organization: "Campus Developer Society", type: "Workshop" as const, location: "Innovation Hall · Room 204", workMode: "On campus" as const, description: "A practical workshop on accessible interfaces, component systems and frontend performance. Bring a laptop and a project you would like to improve.", eligibility: "All current students; beginner friendly.", branches: "All branches", skills: "HTML, CSS, JavaScript", deadline: days(12), externalUrl: "https://example.com/events/frontend-workshop", compensation: "Free · registration required" },
    { title: "Inter-college Robotics Sprint", organization: "Engineering Design Forum", type: "Competition" as const, location: "Tech Arena · Main Campus", workMode: "In person" as const, description: "Design and test a small autonomous rover through timed navigation challenges. Equipment is provided; teams may bring their own controller boards.", eligibility: "Teams of 3–5 undergraduate students.", branches: "All branches", skills: "Arduino, Robotics, CAD", deadline: days(21), externalUrl: "https://example.com/competitions/robotics-sprint", compensation: "Awards and project grants" },
    { title: "Cloud Foundations Learning Series", organization: "Cloud Native Guild", type: "Technical event" as const, location: "Online", workMode: "Remote" as const, description: "Three guided sessions on cloud architecture fundamentals, deployment pipelines and observability, led by volunteer practitioners.", eligibility: "Students with basic command-line experience.", branches: "All branches", skills: "Linux, Docker, Cloud", deadline: days(11), externalUrl: "https://example.com/events/cloud-series", compensation: "Participation certificate" },
    { title: "UX Research Assistant", organization: "Human-Centred Computing Lab", type: "Internship" as const, location: "Campus research lab", workMode: "Hybrid" as const, description: "Support a student-facing research project through interview scheduling, usability sessions and synthesis of qualitative findings.", eligibility: "Year 2 or above; interest in human-computer interaction.", branches: "Computer Science, Design, Psychology", skills: "Research, Figma, Communication", deadline: days(18), externalUrl: "https://example.com/opportunities/ux-research-assistant", compensation: "₹12,000 / month" },
    { title: "National Student Innovation Pitch", organization: "Student Innovation Council", type: "Competition" as const, location: "Online finale", workMode: "Remote" as const, description: "Submit a concise proposal for a student-led solution to a local community challenge. Selected teams receive coaching before the final pitch.", eligibility: "Open to current college students; individual or teams of up to 4.", branches: "All branches", skills: "Communication, Research, Prototyping", deadline: days(14), externalUrl: "https://example.com/competitions/student-innovation-pitch", compensation: "Mentorship and demo grants" },
  ];
  if (seedOpportunities) await db.insert(opportunities).values(items.map(item => ({ ...item, approval: "approved" as const, isVerified: false, isDemo: true, createdBy: null })));
  const notices = [
    { title: "Placement readiness hours open for booking", body: "Career Services has opened short resume-review and mock-interview appointments for the coming two weeks. Bring a current draft and choose a slot through the student portal.", type: "placement" as const, department: "Career Services", deadline: days(10) },
    { title: "Research showcase proposals due next Friday", body: "Departments are invited to nominate student projects for the semester research showcase. Submit a 150-word abstract and faculty contact to your department coordinator.", type: "department" as const, department: "Academic Affairs", deadline: days(8) },
    { title: "CampusConnect listings are demo examples", body: "Opportunities marked DEMO are illustrative examples for product demonstration. Follow the external organizer link and confirm current details before applying. A verified badge is shown only after administrator review.", type: "notice" as const, department: "Student Success", deadline: null },
    { title: "Design & build community meetup", body: "Join peers for an informal evening of project demos, lightning talks and networking. Students from every department are welcome.", type: "event" as const, department: "Campus Developer Society", deadline: days(13) },
  ];
  if (seedAnnouncements) await db.insert(announcements).values(notices.map(item => ({ ...item, isPublished: true, isDemo: true, createdBy: null })));
}
