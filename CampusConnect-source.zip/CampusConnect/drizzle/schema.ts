import { boolean, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const studentProfiles = mysqlTable("student_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  studentId: varchar("studentId", { length: 64 }),
  branch: varchar("branch", { length: 120 }).notNull(),
  year: int("year").notNull(),
  skills: text("skills").notNull(),
  interests: text("interests").notNull(),
  bio: text("bio"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("student_profiles_user_unique").on(table.userId)]);

export const opportunities = mysqlTable("opportunities", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 220 }).notNull(),
  organization: varchar("organization", { length: 180 }).notNull(),
  type: mysqlEnum("type", ["Internship", "Job", "Hackathon", "Technical event", "Workshop", "Competition"]).notNull(),
  location: varchar("location", { length: 180 }).notNull(),
  workMode: mysqlEnum("workMode", ["Remote", "Hybrid", "On campus", "In person"]).default("Remote").notNull(),
  description: text("description").notNull(),
  eligibility: text("eligibility").notNull(),
  branches: text("branches").notNull(),
  skills: text("skills").notNull(),
  deadline: timestamp("deadline").notNull(),
  externalUrl: varchar("externalUrl", { length: 1000 }).notNull(),
  compensation: varchar("compensation", { length: 140 }),
  approval: mysqlEnum("approval", ["pending", "approved", "rejected"]).default("approved").notNull(),
  isVerified: boolean("isVerified").default(false).notNull(),
  isDemo: boolean("isDemo").default(false).notNull(),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("opportunities_type_idx").on(table.type), index("opportunities_deadline_idx").on(table.deadline)]);

export const savedOpportunities = mysqlTable("saved_opportunities", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  opportunityId: int("opportunityId").notNull().references(() => opportunities.id, { onDelete: "cascade" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [uniqueIndex("saved_opportunity_user_unique").on(table.userId, table.opportunityId)]);

export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  opportunityId: int("opportunityId").notNull().references(() => opportunities.id, { onDelete: "cascade" }),
  status: mysqlEnum("status", ["Applied", "Under Review", "Shortlisted", "Interview", "Selected", "Rejected"]).default("Applied").notNull(),
  notes: text("notes"),
  appliedAt: timestamp("appliedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [uniqueIndex("application_user_opportunity_unique").on(table.userId, table.opportunityId), index("applications_user_idx").on(table.userId)]);

export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 220 }).notNull(),
  body: text("body").notNull(),
  type: mysqlEnum("type", ["notice", "placement", "department", "event", "deadline"]).notNull(),
  department: varchar("department", { length: 150 }),
  deadline: timestamp("deadline"),
  isPublished: boolean("isPublished").default(true).notNull(),
  isDemo: boolean("isDemo").default(false).notNull(),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("announcements_created_idx").on(table.createdAt)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type StudentProfile = typeof studentProfiles.$inferSelect;
export type Opportunity = typeof opportunities.$inferSelect;
export type Application = typeof applications.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;
